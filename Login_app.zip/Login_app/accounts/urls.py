from django.contrib import admin
from django.urls import path
from . import views
urlpatterns = [
    
    path('acc/register',views.register , name="register"),
    path('',views.welcome , name="welcome"),
    # path('register2',views.register2 , name="register2"),
    path('acc/login',views.login , name='login'),
    path('acc/success',views.success , name='success'),
    path('logout',views.logout , name='logout'),
    # path('profile_info',views.profile , name='profile')
  ]
