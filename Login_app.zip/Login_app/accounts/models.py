from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import auth
# Create your models here.

# class UserProfile(models.Model):
    
# class User(models.Model):
#     # user = models.ForeignKey(User, unique=True,on_delete=models.CASCADE)
#     user = models.OneToOneField(User, to_field='id' ,on_delete=models.CASCADE)  
#     # id = models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')
#     college_name = models.CharField(max_length=25, default="")
#     contact = models.CharField(max_length=25, default="")
#     college_branch = models.CharField(max_length=25, default="")
#     college_year = models.IntegerField(default=00)
    
    
    
        
